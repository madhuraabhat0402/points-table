package io.cric.pointstable.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cric.pointstable.entity.Team;

@Repository
public interface TeamRepository extends CrudRepository<Team, String> {
	
	@Query(value="SELECT t.name FROM Team t JOIN Match m ON(t.id=m.teamId1 OR t.id=m.teamId2)")
	List<Team> findteam();
	
}

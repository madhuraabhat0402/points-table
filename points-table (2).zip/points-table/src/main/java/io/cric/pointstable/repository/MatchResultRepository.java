package io.cric.pointstable.repository;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cric.pointstable.entity.MatchResult;

	@Repository
	public interface MatchResultRepository extends CrudRepository<MatchResult,String>{

		
	}


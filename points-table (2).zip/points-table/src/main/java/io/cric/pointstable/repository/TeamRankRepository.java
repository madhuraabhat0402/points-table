package io.cric.pointstable.repository;

import org.springframework.data.repository.CrudRepository;

import io.cric.pointstable.entity.TeamRank;

public interface TeamRankRepository extends CrudRepository<TeamRank, String>{

}

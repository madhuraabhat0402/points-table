package io.cric.pointstable.resource;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cric.pointstable.repository.MatchRepository;
import io.cric.pointstable.repository.MatchResultRepository;
import io.cric.pointstable.repository.TeamRankRepository;
import io.cric.pointstable.repository.TeamRepository;

@RestController
public class PointTableResource {
	@Autowired
	MatchRepository matchRepo;
	
	@Autowired
	MatchResultRepository matchResultRepo;
	
	@Autowired
	TeamRepository teamRepo;
	
	@Autowired
	TeamRankRepository teamRankRepo;
	
	@RequestMapping("/table")
	private	void postInt() {
		System.out.print(teamRepo.findteam());
	
	}

}

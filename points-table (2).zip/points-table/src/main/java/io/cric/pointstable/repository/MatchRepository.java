package io.cric.pointstable.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cric.pointstable.entity.Match;

@Repository
public interface MatchRepository extends CrudRepository<Match,String>{

	
	
}

package io.cric.pointstable.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import io.cric.pointstable.entity.Team;

@Repository
public interface TeamRepository extends CrudRepository<Team, String> {
	
	@Query(value="SELECT t.name FROM Team t JOIN Match m ON(t.id=m.teamId1 OR t.id=m.teamId2)")
	List<Team> findteam();
	

		@Query("SELECT t.name, tr.points, tr.netRunRate, " +
			       "(SELECT COUNT(mr1) FROM MatchResult mr1 WHERE (mr1.winnerId = t.id)) AS matchesWon, " +
			       "(SELECT COUNT(mr2) FROM MatchResult mr2 WHERE (mr2.match_id = t.id AND mr2.winnerId != t.id)) AS matchesLost, " +
			       "(SELECT COUNT(mr3) FROM Match mr3 WHERE (mr3.teamId1 = t.id OR mr3.teamId2 = t.id)) AS matchesPlayed " +
			       "FROM Team t " +
			       "JOIN TeamRank tr ON t.id = tr.teamid " +
			       "ORDER BY tr.netRunRate DESC")
			List<Object[]> getTeamStandings2();

}

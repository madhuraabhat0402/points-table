package io.cric.pointstable.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MatchResult")
public class MatchResult {
	
	@Id
	private String match_id;
	private String description;
	private Date date;
	private String result;
	private String winnerId;

}

package io.cric.pointstable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PointsTableApplication {

	public static void main(String[] args) {
		SpringApplication.run(PointsTableApplication.class, args);
	}

}

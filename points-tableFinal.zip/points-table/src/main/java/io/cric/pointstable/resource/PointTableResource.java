package io.cric.pointstable.resource;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cric.pointstable.repository.MatchRepository;
import io.cric.pointstable.repository.MatchResultRepository;
import io.cric.pointstable.repository.TeamRankRepository;
import io.cric.pointstable.repository.TeamRepository;

@RestController
public class PointTableResource {
	@Autowired
	MatchRepository matchRepo;
	
	@Autowired
	MatchResultRepository matchResultRepo;
	
	@Autowired
	TeamRepository teamRepo;
	
	@Autowired
	TeamRankRepository teamRankRepo;
	
	@RequestMapping("/table")
	private	List<Object[]> postInt() {
		System.out.print(teamRepo.getTeamStandings2());
		return teamRepo.getTeamStandings2();
//			  @SuppressWarnings("unchecked")
//			  List<Object[]> records = teamRepo.getTeamStandings2();
//			  return map(Class<T>type, records);
//			}
//	
//			public static <T> List<T> map(Class<T> type, List<Object[]> records){
//				   List<T> result = new LinkedList<>();
//				   for(Object[] record : records){
//				      result.add(map(type, record));
//				   }
//				   return result;
//				}
	}

}

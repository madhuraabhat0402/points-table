package io.cric.pointstable.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Match")
public class Match {

	@Id
	@GeneratedValue
	private String matchId;
	private String teamId1;
	private String teamId2;
}
//INSERT INTO TEAM (id,name) VALUES('t1','RCB');
//INSERT INTO TEAM (id,name) VALUES('t2','RR');
//INSERT INTO TEAM (id,name) VALUES('t3','CSK');
//INSERT INTO TEAM (id,name) VALUES('t4','GT');
//
//
//INSERT INTO MATCH VALUES('m1','t1','t2');
//INSERT INTO MATCH VALUES('m2','t1','t3');
//INSERT INTO MATCH VALUES('m3','t2','t3');
//INSERT INTO MATCH VALUES('m4','t3','t4');
//
//
//INSERT INTO MATCH_RESULT VALUES('m1','2023-12-02','1stMatch','RCB WON BY 6 WICKETS','t1');
//INSERT INTO MATCH_RESULT VALUES('m2','2023-12-03','2ndMatch','RCB WON BY 10 RUNS','t1');
//INSERT INTO MATCH_RESULT VALUES('m3','2023-12-04','3rdMatch','RR WON BY 6 WICKETS','t2');
//INSERT INTO MATCH_RESULT VALUES('m4','2023-12-05','4thMatch','GT WON BY 6 WICKETS','t4');
//
//INSERT INTO TEAM_RANK VALUES('t1',+0.951,2);
//INSERT INTO TEAM_RANK VALUES('t2',+0.493,1);
//INSERT INTO TEAM_RANK VALUES('t3',-0.951,0);
//INSERT INTO TEAM_RANK VALUES('t4',+0.851,1);
//
//
//
//SELECT t.name
//FROM TEAM T
//JOIN MATCH m ON(t.id=m.TEAM_ID1 OR t.id=m.TEAM_ID2)
//JOIN MATCH_RESULTS mr ON(mr.match_id=m.match_id)
//GROUP BY t.name
//ORDER BY COUNT
